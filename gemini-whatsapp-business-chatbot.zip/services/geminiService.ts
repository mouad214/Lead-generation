
import { GoogleGenAI, Chat } from "@google/genai";

let chat: Chat | null = null;

function getChatSession(): Chat {
    if (chat) {
        return chat;
    }

    if (!process.env.API_KEY) {
        throw new Error("API_KEY environment variable not set.");
    }
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: 'You are a helpful and friendly WhatsApp business assistant. Keep your responses concise and conversational, suitable for a chat interface. Use emojis where appropriate.',
        },
    });

    return chat;
}

export async function sendMessageToBot(message: string): Promise<string> {
    try {
        const chatSession = getChatSession();
        const response = await chatSession.sendMessage({ message });
        return response.text;
    } catch (error) {
        console.error("Error sending message to Gemini:", error);
        chat = null; // Reset chat session on error
        throw new Error("Could not get a response from the bot.");
    }
}
