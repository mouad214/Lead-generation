
import React, { useState } from 'react';
import { SendIcon } from './icons';

interface MessageInputProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({ onSendMessage, isLoading }) => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim() && !isLoading) {
      onSendMessage(inputValue);
      setInputValue('');
    }
  };

  return (
    <div className="bg-gray-100 p-3">
      <form onSubmit={handleSubmit} className="flex items-center space-x-3">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Type a message"
          disabled={isLoading}
          className="flex-1 p-3 border-none rounded-full focus:ring-2 focus:ring-[#25D366] outline-none transition duration-200"
          autoComplete="off"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-[#128C7E] text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-[#075E54] transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed"
          aria-label="Send message"
        >
          <SendIcon />
        </button>
      </form>
    </div>
  );
};
