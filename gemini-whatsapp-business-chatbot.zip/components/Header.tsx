
import React from 'react';

export const Header: React.FC = () => {
    return (
        <div className="bg-[#005E54] text-white p-3 flex items-center shadow-md z-10">
            <img 
                src="https://picsum.photos/seed/businessbot/40/40" 
                alt="Profile" 
                className="w-10 h-10 rounded-full mr-4"
            />
            <div>
                <h1 className="text-lg font-semibold">Business Assistant</h1>
                <p className="text-sm text-gray-200">online</p>
            </div>
        </div>
    );
};
