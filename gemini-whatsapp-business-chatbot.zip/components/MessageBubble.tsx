
import React from 'react';
import type { Message } from '../types';
import { CheckmarksIcon } from './icons';

interface MessageBubbleProps {
  message: Message;
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.sender === 'user';
  const bubbleClasses = isUser
    ? 'bg-[#DCF8C6] ml-auto'
    : 'bg-white mr-auto';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-xs md:max-w-md p-2.5 rounded-lg shadow-sm ${bubbleClasses}`}>
        <p className="text-gray-800 text-sm whitespace-pre-wrap">{message.text}</p>
        <div className="flex justify-end items-center mt-1">
          <span className="text-xs text-gray-500 mr-1">{message.timestamp}</span>
          {isUser && <CheckmarksIcon />}
        </div>
      </div>
    </div>
  );
};
