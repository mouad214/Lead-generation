
import React from 'react';

export const SendIcon: React.FC = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    className="w-6 h-6"
  >
    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
  </svg>
);

export const CheckmarksIcon: React.FC = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 16 15"
    width="16"
    height="15"
    className="text-blue-500"
  >
    <path
      fill="currentColor"
      d="M15.01 3.316l-1.31-1.302-7.02 7.01-3.666-3.66-1.31 1.302 4.976 4.97 L15.01 3.316zM9.596 11.88l-1.31-1.302-1.31-1.302-1.31 1.302 2.62 2.62 1.31-1.318z"
    ></path>
  </svg>
);
